# 9-Fitness-Tracker

We, a group of five web developers, Rajavarapu Mohan Maruthi, Chennamsetty Venkata Sai Padmini, Kodati Sri Sai, Dhaanyasri Akshika K and myself Pratim Roy, had built this fitness tracking application. A detailed documentation of the project can be found in the documentation folder.

<h1>Run Locally</h1>

Clone the project from master branch
```git clone https://github.com/INFOTRIXS/9-Fitness-Tracker.git```

Install the dependencies
```npm install```

Start the server
```npm run dev```

#Made with love by
https://github.com/mohan8749
https://github.com/srisai98
https://github.com/dhaanyasri-akshika
https://github.com/Padminichennamsetty
https://github.com/ro78ldt




